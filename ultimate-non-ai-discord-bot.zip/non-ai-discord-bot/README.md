# Ultimate Non-AI Discord Bot (Python)

## Includes
- Slash commands and `?` prefix
- Ban, kick, timeout, warn, clear
- Moderation logs
- Points and leaderboard
- Owner-only bot presence: online, sleep/idle, dnd, off/invisible
- Staff application panel: Trial Helper, Trial Moderator, Trial Developer
- Approve/reject/interview-pending review buttons
- Configurable role assignment on approval
- Application search by ID, user ID, or username
- SQLite database; no AI/provider required

## Setup
1. Upload all files to one folder on your host.
2. Keep your existing `.env` if it already contains the right token. If you need a new one, copy `.env.example` to `.env` and fill it in.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Startup command:
   `python bot.py`

## Discord Developer Portal
Enable **Message Content Intent** and **Server Members Intent** under Bot > Privileged Gateway Intents.
Invite the bot with scopes `bot` and `applications.commands`.
Permissions: View Channels, Send Messages, Embed Links, Read Message History, Manage Messages, Ban Members, Kick Members, Moderate Members, Manage Roles. Avoid Administrator unless you have a specific reason.
The bot's top role must be above any role it assigns.

## Notes
- Set `GUILD_ID` to your server ID for faster guild command sync. The code uses it for sync only when set; slash command registration requires `CLIENT_ID` only for reference in the env, while discord.py syncs through the bot application.
- `off` means invisible/appears offline, not process shutdown.
- Application reviews require `STAFF_REVIEW_CHANNEL_ID` and reviewer role IDs or server Administrator.
- Keep `.env` private; never share bot tokens publicly.
