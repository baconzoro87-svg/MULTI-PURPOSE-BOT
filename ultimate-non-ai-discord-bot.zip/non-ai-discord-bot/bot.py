import os
import sqlite3
from datetime import datetime, timezone
import discord
from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("PREFIX", "?")
OWNER_IDS = {x.strip() for x in os.getenv("OWNER_ID", "").split(",") if x.strip()}
LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL_ID", "0") or 0)
STAFF_REVIEW_CHANNEL_ID = int(os.getenv("STAFF_REVIEW_CHANNEL_ID", "0") or 0)
STAFF_REVIEW_ROLE_IDS = {int(x.strip()) for x in os.getenv("STAFF_REVIEW_ROLE_IDS", "").split(",") if x.strip().isdigit()}
HELPER_ROLE_ID = int(os.getenv("STAFF_HELPER_ROLE_ID", "0") or 0)
MODERATOR_ROLE_ID = int(os.getenv("STAFF_MODERATOR_ROLE_ID", "0") or 0)
DEVELOPER_ROLE_ID = int(os.getenv("STAFF_DEVELOPER_ROLE_ID", "0") or 0)
DB_PATH = os.getenv("DB_PATH", "data.sqlite")

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)
db = sqlite3.connect(DB_PATH)
db.row_factory = sqlite3.Row
db.execute("PRAGMA journal_mode=WAL")
db.executescript("""
CREATE TABLE IF NOT EXISTS points(guild_id TEXT, user_id TEXT, points INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(guild_id,user_id));
CREATE TABLE IF NOT EXISTS warnings(id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT, user_id TEXT, moderator_id TEXT, reason TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS applications(id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id TEXT, user_id TEXT, username TEXT, role TEXT, answers TEXT, status TEXT DEFAULT 'Pending', reviewer_id TEXT, created_at TEXT, updated_at TEXT);
""")
db.commit()

def is_owner(uid):
    return str(uid) in OWNER_IDS

def can_review(member):
    return is_owner(member.id) or member.guild_permissions.administrator or any(r.id in STAFF_REVIEW_ROLE_IDS for r in member.roles)

def embed(title, description, color=0x5865F2):
    return discord.Embed(title=title, description=description, color=color, timestamp=datetime.now(timezone.utc))

async def log(guild, title, description, color=0x5865F2):
    if not LOG_CHANNEL_ID:
        return
    channel = guild.get_channel(LOG_CHANNEL_ID)
    if channel is None:
        try:
            channel = await guild.fetch_channel(LOG_CHANNEL_ID)
        except discord.HTTPException:
            return
    if isinstance(channel, discord.TextChannel):
        try:
            await channel.send(embed=embed(title, description, color))
        except discord.HTTPException:
            pass

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} | Non-AI edition")
    try:
        if os.getenv("GUILD_ID", "").isdigit():
            guild_obj = discord.Object(id=int(os.getenv("GUILD_ID")))
            synced = await bot.tree.sync(guild=guild_obj)
            print(f"Synced {len(synced)} guild slash commands.")
        else:
            synced = await bot.tree.sync()
            print(f"Synced {len(synced)} global slash commands.")
    except Exception as exc:
        print(f"Slash command sync failed: {exc}")
    await bot.change_presence(status=discord.Status.online, activity=discord.Game(name=f"{PREFIX}help"))

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.MissingPermissions):
        await ctx.reply("You don't have permission to use that command.", mention_author=False)
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.reply(f"Missing argument. Use `{PREFIX}help`.", mention_author=False)
    else:
        print(f"Command error: {error}")
        await ctx.reply("An error occurred. Check bot console and permissions.", mention_author=False)

@bot.command(name="help")
async def help_cmd(ctx):
    e = embed("Non-AI Bot Help",
      f"**Moderation:** `{PREFIX}ban`, `{PREFIX}kick`, `{PREFIX}timeout`, `{PREFIX}warn`, `{PREFIX}clear`\n"
      f"**Community:** `{PREFIX}points`, `{PREFIX}leaderboard`\n"
      f"**Staff:** `{PREFIX}staff-panel`, `{PREFIX}application-search`\n"
      f"**Status (owners):** `{PREFIX}status online|sleep|dnd|off`\n"
      f"**Other:** `{PREFIX}setup`, `{PREFIX}help`")
    await ctx.reply(embed=e, mention_author=False)

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason="No reason provided"):
    await member.ban(reason=f"{reason} | By {ctx.author}")
    await log(ctx.guild, "Member banned", f"Target: {member} ({member.id})\nModerator: {ctx.author}\nReason: {reason}", 0xED4245)
    await ctx.reply(f"Banned **{member}**. Reason: {reason}", mention_author=False)
    try: await member.send(f"You were banned from **{ctx.guild.name}**. Reason: {reason}")
    except discord.HTTPException: pass

@bot.tree.command(name="ban", description="Ban a member")
@app_commands.checks.has_permissions(ban_members=True)
@app_commands.describe(member="Member to ban", reason="Reason for the ban")
async def slash_ban(interaction: discord.Interaction, member: discord.Member, reason: str="No reason provided"):
    await member.ban(reason=f"{reason} | By {interaction.user}")
    await log(interaction.guild, "Member banned", f"Target: {member} ({member.id})\nModerator: {interaction.user}\nReason: {reason}", 0xED4245)
    await interaction.response.send_message(f"Banned **{member}**. Reason: {reason}")
    try: await member.send(f"You were banned from **{interaction.guild.name}**. Reason: {reason}")
    except discord.HTTPException: pass

@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason="No reason provided"):
    await member.kick(reason=f"{reason} | By {ctx.author}")
    await log(ctx.guild, "Member kicked", f"Target: {member} ({member.id})\nModerator: {ctx.author}\nReason: {reason}", 0xED4245)
    await ctx.reply(f"Kicked **{member}**. Reason: {reason}", mention_author=False)

@bot.tree.command(name="kick", description="Kick a member")
@app_commands.checks.has_permissions(kick_members=True)
async def slash_kick(interaction: discord.Interaction, member: discord.Member, reason: str="No reason provided"):
    await member.kick(reason=f"{reason} | By {interaction.user}")
    await log(interaction.guild, "Member kicked", f"Target: {member} ({member.id})\nModerator: {interaction.user}\nReason: {reason}", 0xED4245)
    await interaction.response.send_message(f"Kicked **{member}**. Reason: {reason}")

@bot.command()
@commands.has_permissions(moderate_members=True)
async def timeout(ctx, member: discord.Member, minutes: int, *, reason="No reason provided"):
    if minutes < 1 or minutes > 40320:
        return await ctx.reply("Duration must be 1–40320 minutes.", mention_author=False)
    await member.timeout(minutes * 60, reason=f"{reason} | By {ctx.author}")
    await log(ctx.guild, "Member timed out", f"Target: {member} ({member.id})\nDuration: {minutes} minutes\nModerator: {ctx.author}\nReason: {reason}", 0xED4245)
    await ctx.reply(f"Timed out **{member}** for {minutes} minutes.", mention_author=False)

@bot.tree.command(name="timeout", description="Timeout a member")
@app_commands.checks.has_permissions(moderate_members=True)
async def slash_timeout(interaction: discord.Interaction, member: discord.Member, minutes: app_commands.Range[int, 1, 40320], reason: str="No reason provided"):
    await member.timeout(minutes * 60, reason=f"{reason} | By {interaction.user}")
    await log(interaction.guild, "Member timed out", f"Target: {member} ({member.id})\nDuration: {minutes} minutes\nModerator: {interaction.user}\nReason: {reason}", 0xED4245)
    await interaction.response.send_message(f"Timed out **{member}** for {minutes} minutes.")

@bot.command()
@commands.has_permissions(moderate_members=True)
async def warn(ctx, member: discord.Member, *, reason="No reason provided"):
    db.execute("INSERT INTO warnings(guild_id,user_id,moderator_id,reason,created_at) VALUES(?,?,?,?,?)",
               (str(ctx.guild.id), str(member.id), str(ctx.author.id), reason, datetime.now(timezone.utc).isoformat()))
    db.commit()
    await log(ctx.guild, "Member warned", f"Target: {member} ({member.id})\nModerator: {ctx.author}\nReason: {reason}", 0xFAA61A)
    await ctx.reply(f"Warned **{member}**. Reason: {reason}", mention_author=False)

@bot.tree.command(name="warn", description="Warn a member")
@app_commands.checks.has_permissions(moderate_members=True)
async def slash_warn(interaction: discord.Interaction, member: discord.Member, reason: str):
    db.execute("INSERT INTO warnings(guild_id,user_id,moderator_id,reason,created_at) VALUES(?,?,?,?,?)",
               (str(interaction.guild_id), str(member.id), str(interaction.user.id), reason, datetime.now(timezone.utc).isoformat()))
    db.commit()
    await log(interaction.guild, "Member warned", f"Target: {member} ({member.id})\nModerator: {interaction.user}\nReason: {reason}", 0xFAA61A)
    await interaction.response.send_message(f"Warned **{member}**. Reason: {reason}")

@bot.command()
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount: int):
    if not 1 <= amount <= 100:
        return await ctx.reply("Choose 1–100 messages.", mention_author=False)
    deleted = await ctx.channel.purge(limit=amount + 1)
    await ctx.send(embed=embed("Messages cleared", f"Deleted {max(0, len(deleted)-1)} messages."), delete_after=8)

@bot.tree.command(name="clear", description="Delete 1–100 recent messages")
@app_commands.checks.has_permissions(manage_messages=True)
async def slash_clear(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
    deleted = await interaction.channel.purge(limit=amount)
    await interaction.response.send_message(f"Deleted {len(deleted)} messages.", ephemeral=True)

@bot.command()
async def points(ctx, member: discord.Member=None, amount: int=None):
    member = member or ctx.author
    if amount is not None:
        if not (ctx.author.guild_permissions.manage_guild or is_owner(ctx.author.id)):
            return await ctx.reply("Manage Server permission required to change points.", mention_author=False)
        db.execute("INSERT INTO points(guild_id,user_id,points) VALUES(?,?,?) ON CONFLICT(guild_id,user_id) DO UPDATE SET points=MAX(0, points+excluded.points)",
                   (str(ctx.guild.id), str(member.id), amount))
        db.commit()
    row = db.execute("SELECT points FROM points WHERE guild_id=? AND user_id=?", (str(ctx.guild.id), str(member.id))).fetchone()
    await ctx.reply(embed=embed("Member Points", f"{member.mention} has **{row['points'] if row else 0}** points."), mention_author=False)

@bot.tree.command(name="points", description="View a member's points")
async def slash_points(interaction: discord.Interaction, member: discord.Member=None):
    member = member or interaction.user
    row = db.execute("SELECT points FROM points WHERE guild_id=? AND user_id=?", (str(interaction.guild_id), str(member.id))).fetchone()
    await interaction.response.send_message(embed=embed("Member Points", f"{member.mention} has **{row['points'] if row else 0}** points."), ephemeral=True)

@bot.command()
async def leaderboard(ctx):
    rows = db.execute("SELECT user_id, points FROM points WHERE guild_id=? ORDER BY points DESC LIMIT 10", (str(ctx.guild.id),)).fetchall()
    text = "\n".join(f"**{i}.** <@{r['user_id']}> — {r['points']} points" for i, r in enumerate(rows, 1)) or "No points recorded yet."
    await ctx.reply(embed=embed("Points Leaderboard", text), mention_author=False)

@bot.tree.command(name="leaderboard", description="Show the points leaderboard")
async def slash_leaderboard(interaction: discord.Interaction):
    rows = db.execute("SELECT user_id, points FROM points WHERE guild_id=? ORDER BY points DESC LIMIT 10", (str(interaction.guild_id),)).fetchall()
    text = "\n".join(f"**{i}.** <@{r['user_id']}> — {r['points']} points" for i, r in enumerate(rows, 1)) or "No points recorded yet."
    await interaction.response.send_message(embed=embed("Points Leaderboard", text))

def parse_status(value):
    value = value.lower().strip()
    mapping = {
        "on": (discord.Status.online, "Online"), "online": (discord.Status.online, "Online"),
        "sleep": (discord.Status.idle, "Idle / Sleep"), "idle": (discord.Status.idle, "Idle / Sleep"),
        "dnd": (discord.Status.dnd, "Do Not Disturb"), "off": (discord.Status.invisible, "Appears Offline"),
        "offline": (discord.Status.invisible, "Appears Offline")
    }
    return mapping.get(value)

async def set_status(value):
    parsed = parse_status(value)
    if not parsed: return None
    status, label = parsed
    await bot.change_presence(status=status, activity=discord.Game(name=f"{PREFIX}help"))
    return label

@bot.command()
async def status(ctx, value: str=""):
    if not is_owner(ctx.author.id):
        return await ctx.reply("Only configured bot owners can change my status.", mention_author=False)
    label = await set_status(value)
    if not label:
        return await ctx.reply(f"Usage: `{PREFIX}status online|sleep|dnd|off`", mention_author=False)
    await ctx.reply(f"Status changed to **{label}**.", mention_author=False)

@bot.tree.command(name="status", description="Change bot presence (owners only)")
@app_commands.choices(value=[
    app_commands.Choice(name="Online", value="online"),
    app_commands.Choice(name="Sleep / Idle", value="sleep"),
    app_commands.Choice(name="Do Not Disturb", value="dnd"),
    app_commands.Choice(name="Off / Appear Offline", value="off"),
])
async def slash_status(interaction: discord.Interaction, value: app_commands.Choice[str]):
    if not is_owner(interaction.user.id):
        return await interaction.response.send_message("Only configured bot owners can change my status.", ephemeral=True)
    label = await set_status(value.value)
    await interaction.response.send_message(f"Status changed to **{label}**.", ephemeral=True)

class ApplicationView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    @discord.ui.button(label="Apply for Staff", style=discord.ButtonStyle.primary, custom_id="staff:apply")
    async def apply(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Choose a role:", view=RoleSelectView(), ephemeral=True)

class RoleSelect(discord.ui.Select):
    def __init__(self):
        super().__init__(placeholder="Select a staff position", min_values=1, max_values=1, options=[
            discord.SelectOption(label="Trial Helper", value="Trial Helper", description="Member support and tickets"),
            discord.SelectOption(label="Trial Moderator", value="Trial Moderator", description="Moderation and server safety"),
            discord.SelectOption(label="Trial Developer", value="Trial Developer", description="Basic programming and debugging"),
        ])
    async def callback(self, interaction: discord.Interaction):
        role = self.values[0]
        await interaction.response.send_modal(ApplicationModal(role))

class RoleSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(RoleSelect())

class ApplicationModal(discord.ui.Modal):
    def __init__(self, role):
        super().__init__(title=f"{role} Application")
        self.role = role
        if role == "Trial Helper":
            prompts = [("experience", "Support/ticket experience"), ("availability", "When are you available?"), ("scenario", "How help an upset member?")]
        elif role == "Trial Moderator":
            prompts = [("experience", "Moderation experience"), ("scenario", "How handle rule-breaking?"), ("availability", "When are you available?")]
        else:
            prompts = [("languages", "Programming/scripting knowledge"), ("projects", "Projects or debugging experience"), ("scenario", "How troubleshoot a bot error?")]
        self.fields_map = []
        for key, label in prompts:
            field = discord.ui.TextInput(label=label, custom_id=key, style=discord.TextStyle.paragraph, required=True, max_length=800)
            self.add_item(field)
            self.fields_map.append((key, field))
    async def on_submit(self, interaction: discord.Interaction):
        answers = {key: field.value for key, field in self.fields_map}
        now = datetime.now(timezone.utc).isoformat()
        cur = db.execute("INSERT INTO applications(guild_id,user_id,username,role,answers,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                         (str(interaction.guild_id), str(interaction.user.id), str(interaction.user), self.role, json_dumps(answers), "Pending", now, now))
        db.commit()
        app_id = cur.lastrowid
        e = embed(f"Staff Application #{app_id}", f"**Position:** {self.role}\n**Applicant:** {interaction.user.mention} (`{interaction.user.id}`)\n\n" + "\n\n".join(f"**{k}**\n{v}" for k,v in answers.items()))
        sent = False
        channel = interaction.guild.get_channel(STAFF_REVIEW_CHANNEL_ID) if STAFF_REVIEW_CHANNEL_ID else None
        if channel is None and STAFF_REVIEW_CHANNEL_ID:
            try: channel = await interaction.guild.fetch_channel(STAFF_REVIEW_CHANNEL_ID)
            except discord.HTTPException: pass
        if isinstance(channel, discord.TextChannel):
            await channel.send(embed=e, view=ReviewView())
            sent = True
        await log(interaction.guild, "Staff application submitted", f"Application #{app_id} · {self.role} · Applicant {interaction.user} · Review channel notified: {sent}")
        await interaction.response.send_message(f"Application submitted! ID: **#{app_id}**. Status: Pending.", ephemeral=True)

def json_dumps(value):
    import json
    return json.dumps(value, ensure_ascii=False)

class ReviewView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    async def _review(self, interaction, status):
        if not can_review(interaction.user):
            return await interaction.response.send_message("You are not authorized to review applications.", ephemeral=True)
        # Parse application ID from the embed title.
        title = interaction.message.embeds[0].title if interaction.message.embeds else ""
        try: app_id = int(title.split("#")[-1])
        except ValueError: return await interaction.response.send_message("Could not read application ID.", ephemeral=True)
        row = db.execute("SELECT * FROM applications WHERE id=? AND guild_id=?", (app_id, str(interaction.guild_id))).fetchone()
        if not row: return await interaction.response.send_message("Application not found.", ephemeral=True)
        db.execute("UPDATE applications SET status=?, reviewer_id=?, updated_at=? WHERE id=?",
                   (status, str(interaction.user.id), datetime.now(timezone.utc).isoformat(), app_id))
        db.commit()
        role_id = {"Trial Helper": HELPER_ROLE_ID, "Trial Moderator": MODERATOR_ROLE_ID, "Trial Developer": DEVELOPER_ROLE_ID}.get(row["role"], 0)
        if status == "Approved" and role_id:
            member = interaction.guild.get_member(int(row["user_id"]))
            if member:
                try: await member.add_roles(interaction.guild.get_role(role_id), reason=f"Approved staff application #{app_id}")
                except (discord.HTTPException, TypeError): pass
        try:
            user = await bot.fetch_user(int(row["user_id"]))
            await user.send(f"Your **{row['role']}** application #{app_id} in **{interaction.guild.name}** was **{status}**.")
        except discord.HTTPException: pass
        await interaction.response.send_message(f"Application #{app_id} updated: **{status}**.", ephemeral=True)
        await log(interaction.guild, "Staff application reviewed", f"Application #{app_id}\nRole: {row['role']}\nStatus: {status}\nReviewer: {interaction.user.mention}")
    @discord.ui.button(label="Approve", style=discord.ButtonStyle.success, custom_id="staff:approve")
    async def approve(self, interaction, button): await self._review(interaction, "Approved")
    @discord.ui.button(label="Reject", style=discord.ButtonStyle.danger, custom_id="staff:reject")
    async def reject(self, interaction, button): await self._review(interaction, "Rejected")
    @discord.ui.button(label="Interview pending", style=discord.ButtonStyle.primary, custom_id="staff:interview")
    async def interview(self, interaction, button): await self._review(interaction, "Interview Pending")

@bot.command(name="staff-panel")
@commands.has_permissions(manage_guild=True)
async def staff_panel(ctx):
    await ctx.send(embed=embed("Staff Applications", "Click below to apply for Trial Helper, Trial Moderator, or Trial Developer."), view=ApplicationView())

@bot.tree.command(name="staff-panel", description="Post the staff application panel")
@app_commands.checks.has_permissions(manage_guild=True)
async def slash_staff_panel(interaction: discord.Interaction):
    await interaction.channel.send(embed=embed("Staff Applications", "Click below to apply for Trial Helper, Trial Moderator, or Trial Developer."), view=ApplicationView())
    await interaction.response.send_message("Staff application panel posted.", ephemeral=True)

@bot.command(name="application-search")
async def application_search(ctx, *, query: str):
    if not can_review(ctx.author):
        return await ctx.reply("You are not authorized to search applications.", mention_author=False)
    rows = db.execute("SELECT * FROM applications WHERE guild_id=? AND (CAST(id AS TEXT)=? OR user_id=? OR username LIKE ?) ORDER BY id DESC LIMIT 10",
                      (str(ctx.guild.id), query, query, f"%{query}%")).fetchall()
    text = "\n\n".join(f"**#{r['id']}** · {r['role']} · **{r['status']}**\n{r['username']} (`{r['user_id']}`)" for r in rows) or "No matching applications."
    await ctx.reply(embed=embed("Application Search", text), mention_author=False)

@bot.tree.command(name="application-search", description="Search staff applications by ID or user")
@app_commands.checks.has_permissions(manage_guild=True)
async def slash_application_search(interaction: discord.Interaction, query: str):
    if not can_review(interaction.user):
        return await interaction.response.send_message("You are not authorized to search applications.", ephemeral=True)
    rows = db.execute("SELECT * FROM applications WHERE guild_id=? AND (CAST(id AS TEXT)=? OR user_id=? OR username LIKE ?) ORDER BY id DESC LIMIT 10",
                      (str(interaction.guild_id), query, query, f"%{query}%")).fetchall()
    text = "\n\n".join(f"**#{r['id']}** · {r['role']} · **{r['status']}**\n{r['username']} (`{r['user_id']}`)" for r in rows) or "No matching applications."
    await interaction.response.send_message(embed=embed("Application Search", text), ephemeral=True)

@bot.command()
async def setup(ctx):
    await ctx.reply(embed=embed("Configuration", f"Prefix: `{PREFIX}`\nAI: Disabled\nLog channel: {'configured' if LOG_CHANNEL_ID else 'not set'}\nStaff review channel: {'configured' if STAFF_REVIEW_CHANNEL_ID else 'not set'}"), mention_author=False)

@bot.event
async def on_member_join(member):
    await log(member.guild, "Member joined", f"{member.mention} · ID `{member.id}`")

@bot.event
async def on_member_remove(member):
    await log(member.guild, "Member left", f"{member} · ID `{member.id}`")

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN is missing from .env")

bot.run(TOKEN)
